<?php

namespace App\Models;

use CodeIgniter\Model;

class FilterRequestModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = '';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    // function with parameters that checks for an existing records in the database
    // of the service name, vehicle name, and place from request service form page,
    // this function returns the result
    public function filterRequest($service_name, $vehicle_name, $place)
    {
        /*
        // get multiple values of checkbox on service name
        foreach ($service_name as $key => $val) {
            $data[] = array(
                'service_name' => $service_name[$key]
            );
        }
        foreach($data as $item) {
            $item['service_name'];
        } //*/

        return $this->db->table('service_providers_tbl')->
        select('
        service_providers_tbl.user_name AS sp_user_name,
        service_providers_tbl.email AS sp_email,
        offered_serv_tbl.offered_serv_id AS offered_serv_id,
        service_providers_tbl.contact_num AS sp_contact_num,
        service_providers_tbl.user_status AS sp_user_status, 
        service_providers_tbl.owner_name AS sp_owner_name,
        service_providers_tbl.shop_name AS sp_shop_name,  
        service_providers_tbl.location AS sp_location, 
        service_providers_tbl.current_estimated_earnings AS sp_current_estimated_earnings,
        service_providers_tbl.load_balance AS sp_load_balance, 
        service_providers_tbl.name AS sp_name,  
        offered_serv_tbl.offered_serv_id AS offered_serv_id, 
        offered_serv_tbl.user_name AS offered_sp_user_name,
        offered_serv_tbl.service_name AS offered_sp_service_name, 
        offered_serv_tbl.vehicle_name AS offered_sp_vehicle_name, 
        offered_serv_tbl.price AS offered_sp_price,
        serviceable_location_tbl.user_name AS serv_loc_sp_username,
        serviceable_location_tbl.place AS serv_loc_sp_place,
        serviceable_location_tbl.charge AS serv_loc_sp_charge',)
            ->join('offered_serv_tbl', 'service_providers_tbl.user_name = offered_serv_tbl.user_name')
            ->join('serviceable_location_tbl', 'offered_serv_tbl.user_name = serviceable_location_tbl.user_name')
            ->where('offered_serv_tbl.service_name',  $service_name)    // $item['service_name'])
            ->where('offered_serv_tbl.vehicle_name', $vehicle_name)
            ->where('serviceable_location_tbl.place', $place)->get()->getResult();

        // $db = db_connect();
        // return $db->query("SELECT 
        // service_providers_tbl.user_name AS sp_user_name, 
        // service_providers_tbl.email AS sp_email,
        // service_providers_tbl.contact_num AS sp_contact_num,
        // service_providers_tbl.user_status AS sp_user_status, 
        // service_providers_tbl.owner_name AS sp_owner_name,
        // service_providers_tbl.shop_name AS sp_shop_name, 
        // service_providers_tbl.location AS sp_location, 
        // service_providers_tbl.current_estimated_earnings AS sp_current_estimated_earnings,
        // service_providers_tbl.name AS sp_name,  
        // offered_serv_tbl.user_name AS offered_sp_user_name,
        // offered_serv_tbl.service_name AS offered_sp_service_name, 
        // offered_serv_tbl.vehicle_name AS offered_sp_vehicle_name,
        // offered_serv_tbl.price AS offered_sp_price, 
        // serviceable_location_tbl.user_name AS serv_loc_sp_username,
        // serviceable_location_tbl.place AS serv_loc_sp_place,
        // serviceable_location_tbl.charge AS serv_loc_sp_charge'
        // FROM service_providers_tbl
        // INNER JOIN offered_serv_tbl ON service_providers_tbl.user_name = offered_serv_tbl.user_name
        // INNER JOIN serviceable_location_tbl ON offered_serv_tbl.user_name = serviceable_location_tbl.user_name
        // WHERE offered_serv_tbl.service_name IN " . "(" . $sn . ")" . "AND
        // offered_serv_tbl.vehicle_name=" . $vehicle_name . "AND serviceable_location_tbl.place=" . $place)->getResult();
    }
}
