<?php

namespace App\Models;

use CodeIgniter\Model;

class BookRequestModel extends Model
{
    var $table = 'books';

    public function __construct()
    {
        parent::__construct();
        //$this->load->database();
        $db = \Config\Database::connect();
        $builder = $db->table('books');
    }

    public function get_by_username($sp_user_name)
    {
        $sql = 'select * from service_providers_tbl where user_name =' . $sp_user_name;
        $query =  $this->db->query($sql);

        return $query->getRow();
    }

    public function book_update($where, $data)
    {
        $this->db->table($this->table)->update($data, $where);
        //        print_r($this->db->getLastQuery());
        return $this->db->affectedRows();
    }
}
