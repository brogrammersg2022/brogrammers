<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\CustomersModel;
use App\Models\ServiceProvidersModel;

use CodeIgniter\Database\Query;

class Usercontroller extends BaseController
{

    //* Commented
    public function login()
    {
        helper(['form']);
        $data = [];

        if ($this->request->getMethod() == 'post') {

            $rules = [
                'user_name' => 'required|min_length[4]|max_length[50]',
                'password' => 'required|min_length[6]|max_length[255]|validateUser[user_name,password]',
            ];

            $errors = [
                'password' => [
                    'validateUser' => "Username or Password don't match",
                ],
                'user_name' => [
                    'required' => 'Username field is required',
                ],
            ];

            helper(['form']);
            if (!$this->validate($rules, $errors)) {

                // helper(['form']);
                return view('login_page', [
                    "validation" => $this->validator,
                ]);
            } else {
                $model = new UserModel();
                $serviceProviderModel = new ServiceProvidersModel();
                $customerModel = new CustomersModel();

                $user = $model->where('user_name', $this->request->getVar('user_name'))->first();

                // connect to the database
                $db = \Config\Database::connect();
                // $db = db_connect(); //A convenience method exists that is purely a wrapper around the above line and is provided for your convenience:

                // query for the user type of the user that logs in
                $builder = $db->table('users_tbl');
                $results = $builder->getWhere($user);
                foreach ($results->getResult() as $row) {
                    $row->user_type;
                    $row->load_balance;
                    $row->user_status;
                }

                // condition for the user type 
                // user will be redirected to specific dashboard page
                if ($row->user_type == "Service Provider") { // &&  $row->load_balance=="0") {

                    $sp = $serviceProviderModel->where('user_name', $this->request->getVar('user_name'))->first();
                    // Stroing session values
                    $this->set_service_provider_session($sp);
                    $this->setUserSession($user);

                    // Redirecting to dashboard after login
                    return redirect()->to(base_url('service_provider_dashboard'));
                } else if ($row->user_type == "Customer") {
                    $customer = $customerModel->where('user_name', $this->request->getVar('user_name'))->first();
                    // Stroing session values
                    $this->set_customer_session($customer);
                    $this->setUserSession($user);

                    // Redirecting to dashboard after login
                    return redirect()->to(base_url('customer_dashboard'));
                }

                // // Stroing session values
                // $this->setUserSession($user);
                // // echo '<script>alert("You have zero balance");</script>';
                // // Redirecting to dashboard after login
                // return redirect()->to(base_url('dashboard'));

            }
        }
    } //*/


    //*
    public function create_account()
    {

        helper(['form']);
        if ($this->request->getMethod() == 'post') {
            //let's do the validation here
            $rules = [
                'name' => 'required|min_length[3]|max_length[100]',
                'contact_num' => 'required|min_length[11]|max_length[11]',
                //'email' => 'valid_email',
                'user_name' => 'required|min_length[3]|max_length[50]|is_unique[users_tbl.user_name]',
                'password' => 'required|min_length[6]|max_length[255]',
                'user_type' => 'required',
            ];

            $error = [
                'name' => [
                    'required' => "Name field is required",
                ],
                // 'email' => [
                //     'required' => "The email field must be a valid email",
                // ],
                'user_name' => [
                    'required' => "Username field is required",
                    'is_unique' => "Username is already in use",
                    'min_length' => "Minimum length for username is 3 ",
                    'max_length' => "Maximum length for username is 20 ",
                ],
                'contact_num' => [
                    'required' => "Contact Number field is required",
                    'min_length' => "Minimum length for contact number is 11 ",
                    'max_length' => "Maximum length for username is 11 ",
                ],
                'user_type' => [
                    'required' => "Please select a role for your registration",
                ],
            ];

            if (!$this->validate($rules, $error)) {

                return view('register_page', [
                    "validation" => $this->validator,
                ]);
            } else {

                $model = new UserModel();

                $customerModel = new CustomersModel();
                $serviceProviderModel = new ServiceProvidersModel();

                $newData = [
                    'name' => $this->request->getVar('name'),
                    'contact_num' => $this->request->getVar('contact_num'),
                    'email' => $this->request->getVar('email'),
                    'user_name' => $this->request->getVar('user_name'),
                    'password' => $this->request->getVar('password'),
                    'user_type' => $this->request->getVar('user_type'),
                    'load_balance' => "0",
                    'user_status' => "OFFLINE", // SET THE USER STATUS TO OFFLINE BY DEFAULT SINCE USER WILL BE REDIRECTED TO LOGIN PAGE AFTER REGISTRATION AND RELOADING BALANCE

                ];

                // IF CUSTOMER
                if ($newData['user_type'] == "Customer") {
                    $session =  session();

                    $create_customer_data = [
                        'name' => $this->request->getVar('name'),
                        'contact_num' => $this->request->getVar('contact_num'),
                        'email' => $this->request->getVar('email'),
                        'user_name' => $this->request->getVar('user_name'),
                        //'password' => $this->request->getVar('password'),
                        'user_status' => "OFFLINE",
                        'load_balance' => "0",

                    ];

                    $model->save($newData);
                    $customerModel->save($create_customer_data);

                    $session->setFlashdata('msg', view('success_page'));
                    return redirect()->to('load_login_page');

                    // IF SERVICE PROVIDER
                } else if ($newData['user_type'] == "Service Provider") {
                    $session =  session();
                    $create_service_provider_data = [
                        'name' => $this->request->getVar('name'),
                        'contact_num' => $this->request->getVar('contact_num'),
                        'email' => $this->request->getVar('email'),
                        'user_name' => $this->request->getVar('user_name'),
                        // 'password' => $this->request->getVar('password'),
                        'user_status' => "OFFLINE",
                        'load_balance' => "0",
                        'current_estimated_earnings' => "0",

                    ];

                    $model->save($newData);
                    $serviceProviderModel->save($create_service_provider_data);

                    $session->setFlashdata('msg', view('success_page'));
                    return redirect()->to('load_login_page');
                }
            }
        }
    } //*/

    public function checkUserStatus()
    {
    }

    //* Set Service Provider session
    private function set_service_provider_session($user)
    {
        $data = [
            //'user_id' => $user['user_id'], // commented not present from the table
            'name' => $user['name'],
            'email' => $user['email'],
            'contact_num' => $user['contact_num'],
            'user_name' => $user['user_name'],
            //'user_type' => $user['user_type'], // commented not present from the table
            'load_balance' => $user['load_balance'],
            'current_estimated_earnings' => $user['current_estimated_earnings'],
            'user_status' => $user['user_status'],
            'isLoggedIn' => true,
        ];

        session()->set($data);
        return true;
    } //*/

    //* Set Customer session
    private function set_customer_session($user)
    {
        $data = [
            //'user_id' => $user['user_id'], // commented not present from the table
            'name' => $user['name'],
            'email' => $user['email'],
            'contact_num' => $user['contact_num'],
            'user_name' => $user['user_name'],
            //'user_type' => $user['user_type'], // commented not present from the table
            'load_balance' => $user['load_balance'],
            'user_status' => $user['user_status'],
            'isLoggedIn' => true,
        ];

        session()->set($data);
        return true;
    } //*/

    //* // Set the user session
    private function setUserSession($user)
    {
        $data = [
            'user_id' => $user['user_id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'contact_num' => $user['contact_num'],
            'user_name' => $user['user_name'],
            'user_type' => $user['user_type'],
            'load_balance' => $user['load_balance'],
            //'current_estimated_earnings' => $user['current_estimated_earnings'], // commented not present from the table
            'isLoggedIn' => true,
        ];

        session()->set($data);
        return true;
    } //*/

    public function logout()
    {
        session()->destroy();
        return redirect()->to('load_login_page');
    }

    public function load_registration_page()
    {
        helper(['form']);
        $data = [];
        echo view('register_page');
    }

    public function load_login_page()
    {
        helper(['form']);
        $data = [];
        echo view('login_page');
    }
}
