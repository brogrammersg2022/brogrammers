<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\OfferedservicesModel;
use App\Models\ServiceProvidersModel;
use CodeIgniter\Database\Query;

class Offeredservicescontroller extends BaseController {

    public function add() {
        $offeredServicesModel = new OfferedservicesModel();
    }

}