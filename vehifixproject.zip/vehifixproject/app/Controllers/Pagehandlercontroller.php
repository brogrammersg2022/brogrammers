<?php

// his class loads the other page assets for the customers and service providers.
// For the customers, this class shall load the specific sub type of requests,
// e.g. when the customer chooses the Vulcanize service, a page appears that ask
// how many tyres it needs to vulcanize.
// For service providers, this class shall load the pages for the logs and other for
// viewing pages only.
// 
// !!!TO BE UPDATED SOON/LATER!!!

namespace App\Controllers;

use App\Controllers\BaseController;

class Pagehandlercontroller extends BaseController
{

    public function load_account_settings_page()
    {
        return view("account_settings_page");
    }

    // public function load_offered_services_page() {
    //     return view("service providers folder/offered_services_page");
    // }

    public function load_request_service_page()
    {
        helper(['form']);
        $data = [];
        return view("request_service_page");
    }

    // public function load_select_service_page() {
    //     return view('customers folder/select_service_page');
    // }

}
