<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class BookRequestController extends BaseController
{
    public function index()
    {
        //
    }
}
