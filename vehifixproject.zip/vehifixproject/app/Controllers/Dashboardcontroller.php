<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Models\ServiceProvidersModel;
use App\Models\CustomersModel;
use App\Models\UserModel;
use CodeIgniter\Database\Query;

class Dashboardcontroller extends \CodeIgniter\Controller//BaseController
{
    // COMMENTED (DO NOT REMOVE)
    // replace by the *NEW code below
    // public function index()
    // {
    //     return view("dashboard_page");
    // }


    // *NEW
    // loads the specific dashboard page for specific user type
    public function  service_provider_dashboard()
    {
        if (session()->get('user_type') != "Service Provider") {
            echo 'Access denied';
            exit;
        }

        $model = new UserModel();
        $serviceProviderModel = new ServiceProvidersModel();
        
        $user = $model->where('user_name', $this->request->getVar('user_name'))->first();

        // connect to the database
        $db = \Config\Database::connect();
        // $db = db_connect(); //A convenience method exists that is purely a wrapper around the above line and is provided for your convenience:
     
        // query for the user type of the user that logs in
        $builder = $db->table('service_providers_tbl');
        $results = $builder->getWhere($user);
        foreach($results->getResult() as $row) {
            //$row->user_type;
            $row->load_balance;
            $row->user_status;
            $row->current_estimated_earnings;
        }

        $data = [
            'user_status' => [
                $row->user_status, 
            ],
            'load_balance' => [
                $row->load_balance, 
            ],
            'current_estimated_earnings' => [
                $row->current_estimated_earnings,
            ],
        ];

        //$theData = $this->getServiceProviderData();
        //return json_encode($data);
        $this->getServiceProviderData();
        return view("service_provider_dashboard_page", $data);
    }

    public function getServiceProviderData() {
        $model = new UserModel();
        $serviceProviderModel = new ServiceProvidersModel();
        
        $user = $model->where('user_name', $this->request->getVar('user_name'))->first();

        // connect to the database
        $db = \Config\Database::connect();
        $db = db_connect(); //A convenience method exists that is purely a wrapper around the above line and is provided for your convenience:
     
        // query for the user type of the user that logs in
        $builder = $db->table('service_providers_tbl');
        $results = $builder->getWhere($user);
        foreach($results->getResult() as $row) {
            //$row->user_type;
            $row->load_balance;
            $row->user_status;
            $row->current_estimated_earnings;
        }

        $data = [
            'user_status' => [
                $row->user_status, 
            ],
            'load_balance' => [
                $row->load_balance, 
            ],
            'current_estimated_earnings' => [
                $row->current_estimated_earnings,
            ],
        ];

        //$serviceProvider = $serviceProviderModel->where('user_name', $this->request->getVar('user_name'))->findAll();
        return json_encode($data);//$this->response->setJSON($data);
    }

    public function customer_dashboard() 
    {

        if (session()->get('user_type') != "Customer") {
            echo 'Access denied';
            exit;
        }

        $model = new UserModel();
        $customersModel = new CustomersModel();
        
        $user = $model->where('user_name', $this->request->getVar('user_name'))->first();

        // connect to the database
        $db = \Config\Database::connect();
        // $db = db_connect(); //A convenience method exists that is purely a wrapper around the above line and is provided for your convenience:
     
        // query for the user type of the user that logs in
        $builder = $db->table('customers_tbl');
        $results = $builder->getWhere($user);
        foreach($results->getResult() as $row) {
            //$row->user_type;
            $row->load_balance;
            $row->user_status;
        }

        $data = [
            'user_status' => [
                $row->user_status, 
            ],
            'load_balance' => [
                $row->load_balance, 
            ],
        ];
        return view("customer_dashboard_page", $data);
    }
}