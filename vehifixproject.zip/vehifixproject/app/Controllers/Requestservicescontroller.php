<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BookRequestModel;
use App\Models\FilterRequestModel;
use App\Models\OfferedservicesModel;
use App\Models\SelectablePlacesModel;
use App\Models\ServiceProvidersModel;
use App\Models\SelectableServicesModel;
use App\Models\SelectableVehiclesModel;
use CodeIgniter\CLI\Console;
use CodeIgniter\Database\Query;

class Requestservicescontroller extends BaseController
{

    public function view_request_service_page()
    {
        helper(['form']);
        $data = [];

        $selectableServicesModel = new SelectableServicesModel();
        $selectableVehiclesModel = new SelectableVehiclesModel();
        $selectablePlacesModel = new SelectablePlacesModel();

        // $offeredServModel = new OfferedservicesModel();
        // $serviceProvidersModel = new ServiceProvidersModel();

        $db = \Config\Database::connect();
        $builder_selectable_services = $db->table('selectable_services');
        $builder_selectable_vehicles = $db->table('selectable_vehicles');

        $data = [
            'services' => $selectableServicesModel->findAll(),
            'vehicles' => $selectableVehiclesModel->findAll(),
            'places' => $selectablePlacesModel->findAll(),
        ];

        echo view('request_service_form', $data);

        echo view('request_service_page');

        /* // COMMENTED
        if(isset($_POST['submit'])) {
            
            $data = [];
            $db = \Config\Database::connect();
            $service_name = $this->request->getPost('service_name');
            $vehicle_name = $this->request->getPost('vehicle_name');
            $place = $this->request->getPost('place');
    
            $query_sp = $db->query("SELECT service_providers_tbl.shop_name, service_providers_tbl.location, service_providers_tbl.email, service_providers_tbl.contact_num, 
                offered_serv_tbl.service_name, offered_serv_tbl.vehicle_name, offered_serv_tbl.price, serviceable_location_tbl.place, serviceable_location_tbl.charge 
                FROM service_providers_tbl
                INNER JOIN offered_serv_tbl ON service_providers_tbl.user_name=offered_serv_tbl.user_name
                INNER JOIN serviceable_location_tbl ON offered_serv_tbl.user_name=serviceable_location_tbl.user_name
                WHERE offered_serv_tbl.service_name=" . '"' . $service_name . '"' . "AND offered_serv_tbl.vehicle_name=" .
                '"' . $vehicle_name . '"' . "AND serviceable_location_tbl.place=" . '"' . $place . '"');
            
            foreach ($query_sp->getResult() as $sp) {
                $sp->shop_name;
                $sp->service_name;
                $sp->vehicle_name;
                $sp->price;
                $sp->charge;
                $sp->location;
                $sp->place;
            }
    
            
    
            // if($sp->service_name == "" && $sp->vehicle_name == "" && $sp->place == "") {
            if($query_sp->getResult() == NULL) {
                $sp_data = ['mssg' => "No results",];
            } else {
                $sp_data = [
                    'sp_shop' => $sp->shop_name,
                    'sp_service' => $sp->service_name,
                    'sp_price' => $sp->price,
                    'sp_charge' => $sp->charge,
                    'sp_location' => $sp->location,
                    'sp_vehicle' => $sp->vehicle_name,
                    'sp_place' => $sp->place,
                ];
            }
            echo view('sp_list_page', $sp_data);
            }
        }//end of if*/

        // if button named submit from the request_service_form is clicked
        // this code below check if any shop exist in the database records that had offered
        // a service, catered a vehicle, and a location/place that they can reach exist the database records 
        if (isset($_POST['submit'])) {

            $filterRequestModel = new FilterRequestModel();
            $service_name = $this->request->getPost('service_name');
            $vehicle_name = $this->request->getPost('vehicle_name');
            $place = $this->request->getPost('place');

            $query_data['data_item_query'] = $filterRequestModel->filterRequest($service_name, $vehicle_name, $place);
            
            echo view('sp_list_page', $query_data);
            //
        } // end if
        
    }


    /* COMMENTED (PAGE NOT YET USED)
    public function load_account_settings_page()
    {
        return view("service providers folder/account_settings_page");
    } //*/

    // the function to create a book appointment with the selected service provider
    public function ajax_edit($sp_user_name) {
        $this->book_request = new BookRequestModel();
        $data = $this->book_request->get_by_username($sp_user_name);

        echo json_encode($data);
    }

    // the function to insert the customer's request to the requests_tbl
    public function booking_add() {
        $this->book_request = new BookRequestModel();

    }
}
