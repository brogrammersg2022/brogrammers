<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class Noauthserviceprovider implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (session()->get('isLoggedIn')) {

            if (session()->get('user_type') == 'Service Provider') { // && session()->get('user_type')!='Customer') {
                return redirect()->to(site_url('service_provider_dashboard'));
            }
            // else {
            //     return redirect()->to(site_url('service_provider_dashboard'));
            // }


            // return redirect()->to(site_url('service_provider_dashboard'));
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}
