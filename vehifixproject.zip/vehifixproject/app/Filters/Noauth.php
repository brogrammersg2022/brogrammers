<?php 
namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class Noauth implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (session()->get('isLoggedIn')) {
            
            return redirect()->to(site_url('dashboard'));
        }

        // COMMETEND AS NOT USED
        // if(session()->get('isLoggedIn') && session()->get('Service Provider')) {
        //     return redirect()->to(site_url('service_provider_dashboard'));
        // }

        // if(session()->get('isLoggedIn') && session()->get('Customer')) {
        //     return redirect()->to(site_url('customer_dashboard'));
        // }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}