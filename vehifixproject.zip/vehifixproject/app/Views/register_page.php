<?= $this->extend("layouts/app_page") ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Register</div>
            <div class="panel-body">

                <?php if (isset($validation)) : ?>
                    <div class="col-12">
                        <div class="alert alert-danger" role="alert">
                            <?= $validation->listErrors() ?>
                        </div>
                    </div>
                <?php endif; ?>

                <form class="" action="<?= base_url('create_account') ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" value="<?= set_value('name') ?>" name="name" id="name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" value="<?= set_value('email') ?>" name="email" id="email">
                    </div>
                    <div class="form-group">
                        <label for="phone_no">Contact Number</label>
                        <input type="text" class="form-control" value="<?= set_value('contact_num') ?>" name="contact_num" id="contact_num">
                    </div>

                    <div class="form-group">
                        <h3>Register as:</h3>
                        <br>
                        <div class="form-group">
                            <label for="user_type">Customer</label>
                            <input type="radio" class="" name="user_type" id="user_type" value="Customer">
                        </div>
                        <div class="form-group">
                            <label for="user_type">Service Provider</label>
                            <input type="radio" class="" name="user_type" id="user_type" value="Service Provider">
                        </div>
                        <div class="form-group">
                            <label for="Username">Username</label>
                            <input type="text" class="form-control" value="<?= set_value('user_name') ?>" name="user_name" id="username">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password_confirm">Password</label>
                        <input type="password" class="form-control" value="<?= set_value('password') ?>" name="password" id="Password">
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>

                <br>
                <a href="<?php echo ('load_login_page') ?>" type="submit" class="">Back to login</a>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>