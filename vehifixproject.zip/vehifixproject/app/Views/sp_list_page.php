<?= $this->extend("request_service_page") ?>

<div class="container">

    <!-- checks if the returned record record is empty from the query at 
    searching a service provider from the request_service_form page by 
    the customer that had the exact match (service , vehicle, and place) -->

    <?php if ($data_item_query == NULL) { ?>
        <!--  -->
        <h4>No results.</h4>
    <?php } else { ?>

        <h1>List Of Service Providers</h1>
        <br>
        <!-- iterate each results -->
        <h3>Number of results: <?= count($data_item_query) ?> </h3>
        <?php foreach ($data_item_query as $data_item => $row) : ?>

            <div class="card container stretched-link mt-3 border m-5 shadow-lg p-4 mb-4 bg-white">
                <div class="card-body">
                    <div class="" style="width: auto;">
                        <div class="media-body">
                            <input type="text" value="<?= $row->sp_user_name; ?>" name="sp" disabled>
                            <h4> <?= $data_item+=1; ?></h4>
                            <h4>User Name: <?= $row->sp_user_name; ?></h4>
                            <h4>Shop Name: <?= $row->sp_shop_name; ?></h4>
                            <h4>Shop Location: <?= $row->sp_location; ?></h4>

                            <h4>Service: <?= $row->offered_sp_service_name; ?></h4>
                            <h4>Service Fee: <?= $row->offered_sp_price; ?></h4>
                            <h4>Charge Fee: <?= $row->serv_loc_sp_charge; ?></h4>
                            <h4>Selected Location: <?= $row->serv_loc_sp_place; ?></h4>
                            <h4>Contact Details:
                                <br>
                                <?= $row->sp_contact_num; ?>
                                <br>
                                <?= $row->sp_email; ?>
                            </h4>
                            <h4>Selected Vehicle: <?= $row->offered_sp_vehicle_name; ?></h4>
                            <!-- <a class="stretched-link" table-id="$data_item->sp_shop_name" data-toggle="modal" data-target="#bookingForm" href="#"></a> -->
                            <button class="btn btn-primary" data-toggle="modal" data-target="#bookingForm">Book</button>

                        </div>
                    </div>
                </div>
            </div>

            <!-- <div class="border m-5 shadow-lg p-4 mb-4 bg-white">  
            </div> -->


            <!-- modal assets -->
            <!-- CSS -->
            <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
            <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
            <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css') ?>">
            <link rel="stylesheet" href="<?php echo base_url('assets/css/form-elements.css') ?>">
            <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">

            <!-- Favicon and touch icons -->
            <link rel="shortcut icon" href="assets/ico/favicon.png">
            <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url('assets/ico/apple-touch-icon-144-precomposed.png') ?>">
            <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url('assets/ico/apple-touch-icon-114-precomposed.png') ?>">
            <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url('assets/ico/apple-touch-icon-72-precomposed.png') ?>">
            <link rel="apple-touch-icon-precomposed" href="<?php echo base_url('assets/ico/apple-touch-icon-57-precomposed.png') ?>">

            <!-- Javascript -->
            <script src="<?php echo base_url('assets/js/jquery-1.11.1.min.js') ?>"></script>
            <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
            <script src="<?php echo base_url('assets/js/jquery.backstretch.min.js') ?>"></script>
            <script src="<?php echo base_url('assets/js/retina-1.1.0.min.js') ?>"></script>
            <script src="<?php echo base_url('assets/js/scripts.js') ?>"></script>

            <!-- The Modal -->
            <div class="modal" id="bookingForm">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">

                            <h4 class="modal-title">Book an Appointment from <?= $row->sp_shop_name; ?></h4>

                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <br>

                        <h4>Item <?php echo $data_item ?></h4>
                        <h4>Shop: <?= $row->sp_shop_name; ?></h4>
                        <h4>Service: <?= $row->offered_sp_service_name; ?></h4>
                        <h4>Service Fee: <?= $row->offered_sp_price; ?></h4>
                        <h4>Charge Fee: <?= $row->serv_loc_sp_charge; ?></h4>


                        <br>
                        <input type="text" value="<?= $row->sp_shop_name; ?>" name="date" class="form-control" disabled>


                        <!-- Modal body -->
                        <div class="modal-body">
                            <form action="<?= base_url('view_request_service_page') ?>" method="POST" id="request_service_form">

                                <div class="form-group">
                                    <label for="" class="control-label">Date</label>
                                    <input type="date" value="" name="date" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label for="" class="control-label">Time</label>
                                    <input type="time" value="" name="time" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label for="" class="control-label">Note</label>
                                    <input type="text" value="" name="note" class="form-control" required>
                                </div>

                                <hr>

                                <button type="submit" class="btn btn-primary" name="submit">Book Appointment</button>
                            </form>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end of modal -->

            <?php //include 'booking_form.php' 
            ?>

        <?php endforeach; ?>
        <!-- end for each -->

    <?php } ?>
    <!-- end if-else -->

</div>

<?= $this->section("body") ?>