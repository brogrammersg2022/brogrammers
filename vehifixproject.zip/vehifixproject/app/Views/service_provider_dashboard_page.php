<?= $this->extend("layouts/app_page") ?>
<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Dashboard</div>
            <div class="panel-body">


                <!-- navigation tab bar -->
                <div class="container mt-3">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#menu">Menu</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#bookmark_requests">Bookmark Requests</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#logs">Logs</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">

                        <!-- menu tab-->
                        <div id="menu" class="container tab-pane fade"><br>
                            <!-- <h3>Menu</h3> -->
                            <h1>Hello, <?= session()->get(esc('name')) ?></h1>
                            <p>Email: <?= session()->get(esc('email')) ?></p>
                            <p>Contact Number: <?= session()->get(esc('contact_num')) ?></p>
                            <p>User type: <?= session()->get(esc('user_type')) ?></p>
                            <p>User name: <?= session()->get(esc('user_name')) ?></p>

                            <?php foreach ($load_balance as $user_load_balance) : ?>
                                <p class="user_load_balance">Load Balance: <?= esc($user_load_balance) ?></p>
                            <?php endforeach ?>

                            <?php foreach ($current_estimated_earnings as $user_current_estimated_earnings) : ?>
                                <p class="user_current_estimated_earnings">Current Estimated Earnings: <?= esc($user_current_estimated_earnings) ?></p>
                            <?php endforeach ?>

                            <?php foreach ($user_status as $status) : ?>
                                <p class="user_status">User Status: <?= esc($status) ?></p>
                            <?php endforeach ?>

                            <br>
                            <h4><a href="<?= site_url('load_account_settings_page') ?>">Account Settings</a></h4>
                            <br>

                            <h3><a href="<?= site_url('logout') ?>">Logout</a></h3>
                        </div>

                        <!-- logs tab -->
                        <div id="logs" class="container tab-pane active"><br>
                            <h3>Logs</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>

                        <!-- bookmark requests tab -->
                        <div id="bookmark_requests" class="container tab-pane fade"><br>
                            <h3> Bookmark Requests</h3>
                            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>

                    </div>
                </div>
                <!-- end of navigation tab bar -->


            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>