<?= $this->extend("layouts/app_page") ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">

    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Dashboard</div>
            <div class="panel-body">
                
                <h1>Hello, <?= session()->get(esc('name')) ?></h1>
                <p>Email: <?= session()->get(esc('email')) ?></p>
                <p>Contact Number: <?= session()->get(esc('contact_num')) ?></p>
                <p>User type: <?= session()->get(esc('user_type')) ?></p>
                <p>User name: <?= session()->get(esc('user_name')) ?></p>

                <?php foreach($load_balance as $user_load_balance): ?>
                <p>Load Balance: <?= esc($user_load_balance) ?></p>
                <?php endforeach ?>

                <?php foreach($user_status as $status): ?>
                <p>User Status: <?= esc($status) ?></p>
                <?php endforeach ?>

                <br>

                <!-- Button to Open the Modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                <h4>Menu</h4>
                </button>

                <!-- opens the menu modal page when user clicks of Menu button -->
                <?php include 'customer_menu.php'?> 

                <br>
                <!-- <h3><a href="<?= site_url('logout') ?>">Logout</a></h3> -->
            </div>
        </div>
    </div>
</div>



<?= $this->endSection() ?>