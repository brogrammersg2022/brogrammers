<?= $this->extend("layouts/app_page") ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Dashboard</div>
            <div class="panel-body">
                
                <h1>Hello, <?= session()->get(esc('name')) ?></h1>
                <p>ID, <?= session()->get(esc('user_id')) ?></h1>
                <p>Email: <?= session()->get(esc('email')) ?></p>
                <p>Contact Number: <?= session()->get(esc('contact_num')) ?></p>
                <p>User type: <?= session()->get(esc('user_type')) ?></p>
                <p>User name: <?= session()->get(esc('user_name')) ?></p>
                <p>Load balance: <?= session()->get(esc('load_balance')) ?></p>

                <br>
                <h3><a href="<?= site_url('logout') ?>">Logout</a></h3>
            </div>
        </div>
    </div>
</div>


<?= $this->endSection() ?>