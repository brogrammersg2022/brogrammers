<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
  <br>

  <a href="<?php echo ('customer_dashboard') ?>" class="">Back</a>
  <br>
  <br>

  <!-- Button to Open the Modal -->
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Search for Service Provider
  </button>

  <br>

  <?php include 'request_service_form.php' ?>
  <br>
  <?php
  // checks if the input fields from the request_service_form page are empty (unchecked) or not
  if (empty($_POST['service_name']) && empty($_POST['vehicle_name']) && empty($_POST['place'])) {
  ?>
    <!-- display a message if empty (usually during the visit of the user) -->
    <h4>You have not entered your service request, to search tap/click on the Search for Service Provider button above and follow the steps.</h4>
  <?php } else { ?>
    <!-- <h2>You have entered something.</h2> -->
    <?php

    // if button named submit is clicked at request_service_form page
    if (isset($_POST['submit'])) { ?>
      <!-- <p>Selected services:</p> -->
    <?php

      // DO NOT REMOVE
      // THIS COMMENTED CODE WORKS ONLY ON CHECKBOX INPUT
      /*if (!empty($_POST['service_name'])) { ?>
        <p>Selected Services: </p>
      <?php  foreach ($_POST['service_name'] as $service_name) {
          echo '<p> ' . $service_name . ' </p>';
        }
      } //*/

      // display the selected value from the request_service_form page when user clicks on submit button
      if (isset($_POST['service_name'])) {
        echo "<p>Service selected: " . $_POST['service_name'] . "</p>";  //  Displaying Selected Value
      }
      if (isset($_POST['vehicle_name'])) {
        echo "<p>Selected Vehicle: " . $_POST['vehicle_name'] . "</p>";  //  Displaying Selected Value
      }
      if (isset($_POST['place'])) {
        echo "<p>Selected Place: " . $_POST['place'] . "</p>";  //  Displaying Selected Value
      }
    }
    ?>

    <!-- <h2>List of service providers:</h2> -->
  <?php } ?>

  <br>

  <?= $this->renderSection("body") ?>

</body>

</html>