<?= $this->extend("layouts/app_page") ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Login</div>
            <div class="panel-body">

                <?php if (session()->getFlashdata('msg')) : ?>
                    <div><?= session()->getFlashdata('msg') ?></div>
                <?php endif; ?>

                <?php if (isset($validation)) : ?>
                    <div class="col-12">
                        <div class="alert alert-danger" role="alert">
                            <?= $validation->listErrors() ?>
                        </div>
                    </div>
                <?php endif; ?>
                <form class="" action="<?= base_url('login') ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" value="<?= set_value('user_name') ?>" name="user_name" id="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" value="<?= set_value('password') ?>" name="password" id="password">
                    </div>
                    <button type="submit" class="btn btn-success">Login</button>
                </form>

                <br>
                <a href="<?php echo ('load_registration_page') ?>" class="">Register</a>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>