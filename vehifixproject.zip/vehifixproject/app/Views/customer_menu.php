
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Menu</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
            <h2><a href="#">Account Settings</a></h2>
            <h2><a href="<?= site_url('view_request_service_page') ?>">Request A Service</a></h2>
            <h2><a href="#">Load Balance</a></h2>
            <h2><a href="#">Message History</a></h2>
            <h2><a href="#">Help & FAQs</a></h2>
            <h2><a href="<?= site_url('logout') ?>">Logout</a></h2>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>

      
    </div>
  </div>
</div>