 <!-- CSS -->
 <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
 <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
 <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css') ?>">
 <link rel="stylesheet" href="<?php echo base_url('assets/css/form-elements.css') ?>">
 <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">

 <!-- Favicon and touch icons -->
 <link rel="shortcut icon" href="assets/ico/favicon.png">
 <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url('assets/ico/apple-touch-icon-144-precomposed.png') ?>">
 <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url('assets/ico/apple-touch-icon-114-precomposed.png') ?>">
 <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url('assets/ico/apple-touch-icon-72-precomposed.png') ?>">
 <link rel="apple-touch-icon-precomposed" href="<?php echo base_url('assets/ico/apple-touch-icon-57-precomposed.png') ?>">

 <!-- Javascript -->
 <script src="<?php echo base_url('assets/js/jquery-1.11.1.min.js') ?>"></script>
 <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
 <script src="<?php echo base_url('assets/js/jquery.backstretch.min.js') ?>"></script>
 <script src="<?php echo base_url('assets/js/retina-1.1.0.min.js') ?>"></script>
 <script src="<?php echo base_url('assets/js/scripts.js') ?>"></script>

 <!-- The Modal -->
 <div class="modal" id="myModal">
     <div class="modal-dialog">
         <div class="modal-content">

             <!-- Modal Header -->
             <div class="modal-header">
                 <h4 class="modal-title">Modal Heading</h4>
                 <button type="button" class="close" data-dismiss="modal">&times;</button>
             </div>

             <!-- Modal body -->
             <div class="modal-body">
                 <form action="<?= base_url('view_request_service_page') ?>" method="POST" id="request_service_form">

                     <div class="">
                         <h2>Select a service</h2>
                         <p>Select a service</p>
                         <input class="form-control" id="myInput" type="text" placeholder="Search..">
                         <br>
                         <table class="table ">
                             <tbody id="myTable">
                                 <!-- list of services -->
                                 <?php foreach ($services as $row_service_name) : ?>
                                     <tr>
                                         <td>
                                             <label class="form-check-label form-check">
                                                 <!-- <input type="checkbox" class="form-check-input" name="service_name[]" value="<?= esc($row_service_name['service_name']) ?>"> -->
                                                 <input type="radio" class="form-check-input" name="service_name" value="<?= esc($row_service_name['service_name']) ?>">
                                                 <?= esc($row_service_name['service_name']) ?>
                                             </label>
                                         </td>
                                     </tr>
                                 <?php endforeach; ?>
                             </tbody>
                         </table>
                     </div>
                     <script>
                         $(document).ready(function() {
                             $("#myInput").on("keyup", function() {
                                 var value = $(this).val().toLowerCase();
                                 $("#myTable tr").filter(function() {
                                     $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                                 });
                             });
                         });
                     </script>

                     <div class="">
                         <h2>Select the vehicle</h2>
                         <p>Select your vehicle</p>
                         <input class="form-control" id="myInputVehicle" type="text" placeholder="Search..">
                         <br>
                         <table class="table ">
                             <tbody id="myTableVehicle">
                                 <!-- list of services -->
                                 <?php foreach ($vehicles as $row_vehicle_name) : ?>
                                     <tr>
                                         <td>
                                             <label class="form-check-label form-check">
                                                 <input type="radio" class="form-check-input" name="vehicle_name" value="<?= esc($row_vehicle_name['vehicle_name']) ?>" required>
                                                 <?= esc($row_vehicle_name['vehicle_name']) ?>
                                             </label>
                                         </td>
                                     </tr>
                                 <?php endforeach; ?>
                             </tbody>
                         </table>
                     </div>
                     <script>
                         $(document).ready(function() {
                             $("#myInputVehicle").on("keyup", function() {
                                 var value = $(this).val().toLowerCase();
                                 $("#myTableVehicle tr").filter(function() {
                                     $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                                 });
                             });
                         });
                     </script>


                     <div class="">
                         <h2>Your Location</h2>
                         <p>Select your location</p>
                         <input class="form-control" id="myInputPlace" type="text" placeholder="Search..">
                         <br>
                         <table class="tablePlace ">
                             <tbody id="myTablePlace">
                                 <!-- list of services -->
                                 <?php foreach ($places as $row_place_name) : ?>
                                     <tr>
                                         <td>
                                             <label class="form-check-label form-check">
                                                 <input type="radio" class="form-check-input" name="place" value="<?= esc($row_place_name['place']) ?>">
                                                 <?= esc($row_place_name['place']) ?>
                                             </label>
                                         </td>
                                     </tr>
                                 <?php endforeach; ?>
                             </tbody>
                         </table>
                     </div>
                     <script>
                         $(document).ready(function() {
                             $("#myInputPlace").on("keyup", function() {
                                 var value = $(this).val().toLowerCase();
                                 $("#myTablePlace tr").filter(function() {
                                     $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                                 });
                             });
                         });
                     </script>

                     <br>
                     <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                 </form>
             </div>

             <!-- Modal footer -->
             <div class="modal-footer">
                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
             </div>

         </div>
     </div>
 </div>