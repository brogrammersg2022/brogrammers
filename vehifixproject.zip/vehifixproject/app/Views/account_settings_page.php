<!-- the account settings page for service provider -->
<div>
    <h4><a href="<?= site_url('load_offered_services_page') ?>">Update Offered Services</a></h4>
    <h4><a href="#">Update Area Serviceable</a></h4>
    <h4><a href="<?= site_url('service_provider_dashboard') ?>">Back</a></h4>
</div>
