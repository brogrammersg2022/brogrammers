<?= $this->extend("layouts/app_page") ?>

<?= $this->section("body") ?>

<div class="container">

    <form action="#" method="POST">
        <fieldset>
            <!-- offered services -->
            <div class="form-group">
            
                <label for="service">Select Service:</label>
                <select class="form-control" name="service" id="service">
                    <option></option>
                </select>
                <br>
                <br>
                <label for="service_type">Select the sub-type:</label>
                <select class="form-control" name="service_type" id="service_type">
                    <option></option>
                </select>
            </div>

            <br>

            <!-- serviceable vehicle for the offered service -->
            <div class="form-group">
                <label for="brand">Select Brand:</label>
                <select class="form-control" name="brand" id="brand">
                    <option></option>
                    
                </select>
                <br>
                <br>
                <label for="model">Select the Model:</label>
                <select class="form-control" nme="model" id="model">
                    <option></option>
                   
                </select>
            </div>
            
            <br>

            <!-- price of the offered service -->
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" name="price" id="price">
            </div>

            <br>
            <input type="submit" value="Add">
        </fieldset>
    </form>    

    <br>

    <h4><a href="<?= site_url('service_provider_dashboard') ?>">Back</a></h4>
</div>

<?= $this->endSection() ?>