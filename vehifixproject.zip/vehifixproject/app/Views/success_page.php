<script>
    alert("Thank you for signing up! Please login your account");
</script>