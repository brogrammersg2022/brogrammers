<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\SecureHeaders;

use App\Filters\Auth;
use App\Filters\Noauth;

use App\Filters\Authserviceprovider;
use App\Filters\Authcustomer;
use App\Filters\Noauthserviceprovider;
use App\Filters\Noauthcustomer;

class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     *
     * @var array
     */
    public $aliases = [
        'csrf'          => CSRF::class,
        'toolbar'       => DebugToolbar::class,
        'honeypot'      => Honeypot::class,
        'invalidchars'  => InvalidChars::class,
        'secureheaders' => SecureHeaders::class,

        // COMMENTED (DO NOT REMOVE)
        // replace by the *NEW code below
        // "auth" => Auth::class,
        // "noauth" => Noauth::class,

        // *NEW
        // an Auth[user type] class is when the user (either the service provider or customer) tries to open the dashboard page
        // the user will be redirected to the login page
        // an Noauth[user type] class is for the user's session to keep alive as long as still login from the browser 
        "authserviceprovider" => Authserviceprovider::class,
        "authcustomer" => Authcustomer::class,
        "noauthserviceprovider" => Noauthserviceprovider::class,
        "noauthcustomer" => Noauthcustomer::class,
    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     *
     * @var array
     */
    public $globals = [
        'before' => [
            // 'honeypot',
            // 'csrf',
            // 'invalidchars',
        ],
        'after' => [
            'toolbar',
            // 'honeypot',
            // 'secureheaders',
        ],
    ];

    /**
     * List of filter aliases that works on a
     * particular HTTP method (GET, POST, etc.).
     *
     * Example:
     * 'post' => ['csrf', 'throttle']
     *
     * @var array
     */
    public $methods = [];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     *
     * Example:
     * 'isLoggedIn' => ['before' => ['account/*', 'profiles/*']]
     *
     * @var array
     */
    public $filters = [];
}
