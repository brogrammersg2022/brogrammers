<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
//$routes->setDefaultController('Home');
//$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
//$routes->get('/', 'Home::index');


//...

$routes->get('load_registration_page', 'Usercontroller::load_registration_page'); // get the registration page
$routes->get('load_login_page', 'Usercontroller::load_login_page'); // get the login page


// *NEW
// routes for the specific controllers ang pages
$routes->match(['get', 'post'], 'create_account', 'Usercontroller::create_account', ['filter' => 'noauthserviceprovider']); // the logical class for user register
$routes->match(['get', 'post'], 'create_account', 'Usercontroller::create_account', ['filter' => 'noauthcustomer']); 

$routes->match(['get', 'post'], 'login', 'Usercontroller::login', ['filter' => 'noauthcustomer']); // the logical class for user login
$routes->match(['get', 'post'], 'login', 'Usercontroller::login', ['filter' => 'noauthserviceprovider']);

$routes->get('customer_dashboard', 'Dashboardcontroller::customer_dashboard', ['filter' => 'authcustomer']);
$routes->get('service_provider_dashboard', 'Dashboardcontroller::service_provider_dashboard', ['filter' => 'authserviceprovider']);

// load these/this page(s) for the service provider from the class Pagehandlercontroller
$routes->get('load_account_settings_page', 'Pagehandlercontroller::load_account_settings_page'); 
$routes->get('load_offered_services_page', 'Pagehandlercontroller::load_offered_services_page'); 

// load these/this page(s) for the customer from the Pagehandlercontroller
$routes->get('load_request_service_page', 'Pagehandlercontroller::load_request_service_page');

//view_request_service_page
$routes->get('view_request_service_page', 'Requestservicescontroller::view_request_service_page'); 
// $routes->post('view_request_service_page', 'Requestservicescontroller::view_request_service_page');

$routes->get('compare_select_sp_page', 'Requestservicescontroller::compare_select_sp_page'); 
$routes->post('compare_select_sp_page', 'Requestservicescontroller::compare_select_sp_page');


$routes->get('load_compare_select_sp_page', 'Requestservicescontroller::load_compare_select_sp_page'); 
$routes->post('load_compare_select_sp_page', 'Requestservicescontroller::load_compare_select_sp_page'); 

$routes->get('load_recommended_sp', 'Requestservicescontroller::load_recommended_sp');

// route to get the display and view the page that contains data queried from the database
$routes->get('view_request_service_page', 'Requestservicescontroller::view_request_service_page');
$routes->post('view_request_service_page', 'Requestservicescontroller::view_request_service_page');

// same from above
$routes->post('get_recommended_sp', 'Requestservicescontroller::get_recommended_sp');

// COMMENTED CODES ARE TO BE REMOVED LATER
// $routes->get('getServiceProviderData', 'Pagehandlercontroller::getServiceProviderData');
// $routes->post('getServiceProviderData', 'Pagehandlercontroller::getServiceProviderData');

// COMMENTED (DO NOT REMOVE YET) 
// replace by the *NEW code above
// $routes->get('dashboard', 'Dashboardcontroller::index', ['filter' => 'auth']); 
// $routes->match(['get', 'post'], 'create_account', 'Usercontroller::create_account', ['filter' => 'noauth']); // the logical class for user register
// $routes->match(['get', 'post'], 'login', 'Usercontroller::login', ['filter' => 'noauth']); // the logical class for user login
// -----
// $routes->get('customer_dashboard', 'Dashboardcontroller::customer_dashboard', ['filter' => 'auth']);
// $routes->get('service_provider_dashboard', 'Dashboardcontroller::service_provider_dashboard', ['filter' => 'auth']);


// $routes->get('profile', 'User::profile', ['filter' => 'auth']);
$routes->get('logout', 'Usercontroller::logout');


//...


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
